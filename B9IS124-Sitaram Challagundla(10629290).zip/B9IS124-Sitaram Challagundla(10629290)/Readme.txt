The application "TasteBest" is implemented with the android technology. 


Features:
Admin can login into the application.
Users can register into the application with name, email, password, and contact number.
If the user has already registered an account, then the user can directly login into the application with an email and password.
Admin can add any new food item.
Admin can edit or delete any food item.
Users can add any selected food to the cart and then the user can check out the item.

Permission:
File Manager 
Camera


Version
TasteBest 1.0

